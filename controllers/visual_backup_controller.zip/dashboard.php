<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
class Dashboard extends Controller{
	function __construct() {
		parent::__construct();
		
	}
	function index(){
	
	}
	
	
	function login(){
		$this->view->show('dashboard/login');
		exit();		
	}
	
	function signin(){
		if($_POST)
        {
		$email = $_POST['email'];
		$core_password = $_POST['password'];
		$password = md5($_POST['password']);
		$remember = $_POST['remember_me'];
		$timezone = $_POST['timezone'];
		$result=$this->model->getAllWhere('users',array('email'=>$email,'password'=>$password));
		print_r($result);
		
		}else
        {
			$result=array('success'=>0,'msg'=>'Unknown Method.');
			echo json_encode($result);
            exit();
        }
	}
}
?>